<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc($title??'POS') ?> · Point of Sale</title>
<style>
body{margin:0;background:#f5f7fb;color:#1d2939;font:15px Arial,sans-serif}
nav{background:#102a43;color:#fff;padding:14px 5%;display:flex;gap:8px;align-items:center;flex-wrap:wrap}
nav a{color:#d9e2ec;text-decoration:none}.brand{font-size:20px;font-weight:bold;margin-right:auto;padding:8px 10px}
.tab{padding:9px 12px;border-radius:6px}.tab:hover,.tab.active{background:#147d92;color:#fff}
.wrap{max-width:1100px;margin:34px auto;padding:0 20px}h1{margin-top:0}
.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.card,table,form{background:white;border:1px solid #d9e2ec;border-radius:10px;padding:20px;box-shadow:0 2px 8px #102a4310}
.stat{font-size:32px;font-weight:bold;margin-top:10px}table{width:100%;border-collapse:collapse;padding:0}
th,td{padding:13px;border-bottom:1px solid #e6edf3;text-align:left}th{background:#eaf2f8}
input,select{width:100%;padding:10px;margin:6px 0 14px;border:1px solid #bcccdc;border-radius:6px;box-sizing:border-box}
button,.btn{background:#147d92;color:white;border:0;border-radius:6px;padding:10px 14px;text-decoration:none;cursor:pointer}
.btn.secondary{background:#627d98}.btn.danger{background:#c0392b}.actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.back{display:inline-block;margin-bottom:14px;color:#486581;text-decoration:none}.flash{padding:12px;border-radius:6px;margin-bottom:14px;background:#e3fcef;color:#176b47}
.error{background:#fff0f0;color:#a61b1b}.login{max-width:420px;margin:80px auto}.muted{color:#627d98}
@media(max-width:700px){.grid{grid-template-columns:1fr}nav{padding:12px}.brand{width:100%}table{display:block;overflow-x:auto}}
</style>
</head>
<body>
<?php if(session('isLoggedIn')): ?>
<?php $path=trim(uri_string(),'/'); ?>
<nav>
<a class="brand" href="/dashboard">POS System</a>
<a class="tab <?= $path==='' || $path==='dashboard' ? 'active' : '' ?>" href="/dashboard">Dashboard</a>
<a class="tab <?= str_starts_with($path,'products') ? 'active' : '' ?>" href="/products">Products</a>
<a class="tab <?= str_starts_with($path,'customers') ? 'active' : '' ?>" href="/customers">Customers</a>
<a class="tab <?= str_starts_with($path,'staff') ? 'active' : '' ?>" href="/staff">Staff</a>
<a class="tab <?= str_starts_with($path,'sales') ? 'active' : '' ?>" href="/sales">Sales</a>
<a href="/sales/create" class="btn">Record sale</a><a class="tab" href="/logout">Sign out</a>
</nav>
<?php endif ?>
<main class="wrap">
<?php if($m=session()->getFlashdata('success')): ?><div class="flash"><?= esc($m) ?></div><?php endif ?>
<?php if($m=session()->getFlashdata('error')): ?><div class="flash error"><?= esc($m) ?></div><?php endif ?>
<?= $content ?>
</main>
</body>
</html>
